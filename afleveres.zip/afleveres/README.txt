Projektet gør brug af en 20x4 karakters lcd, og der bruges derfor et eksternt library til at drive denne.
library kan hentes fra følgende link:
https://github.com/johnrickman/LiquidCrystal_I2C